
Whatka! is free for personal use.

If you like this font or if you use it for commercial purposes
please give a donation through paypal:
donate@phospho.at

Feel free to distribute this font as long as you include this text file.
cheers!

(C) 2011, phospho type foundry
www.phospho.at
